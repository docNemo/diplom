﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LinguisticDatabase
{
    public partial class ParamsKrepr
    {
        public long IdParam { get; set; }
        public string Param { get; set; }
    }
}
