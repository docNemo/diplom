﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LinguisticDatabase
{
    public partial class ParamsOntology
    {
        public long IdParam { get; set; }
        public string Param { get; set; }
    }
}
