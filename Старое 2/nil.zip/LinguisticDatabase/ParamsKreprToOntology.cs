﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LinguisticDatabase
{
    public partial class ParamsKreprToOntology
    {
        public long IdMatch { get; set; }
        public long IdKreprParam { get; set; }
        public long IdOntologyParam { get; set; }
    }
}
