﻿namespace NL_text_representation.DatabaseInteraction.Entities
{
    public class DBTerms
    {
        public long ID { get; set; }
        public string PartOfSpeech { get; set; }
        public string SubClass { get; set; }
    }
}
